<?php
$config = array(
    'driver' => 'pgsql',
    'host' => 'localhost',
    'dbname' => 'loja',
    'user' => 'aplicacao',
    'pass' => '123456'
);