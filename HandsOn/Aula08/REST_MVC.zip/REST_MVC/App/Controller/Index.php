<?php
namespace Controller;

class Index
{

    public function index()
    {
        echo '<h1 align="center">WELCOME</h1>';
    }
    
    public function sair()
    {
        echo '<h1 align="center">bla bla bla</h1>';
    }
}